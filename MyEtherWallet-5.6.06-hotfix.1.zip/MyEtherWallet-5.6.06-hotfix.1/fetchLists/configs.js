module.exports = {
  MAIN_LISTS_PATH: './fetchLists/lists',
  TOKENS_PATH: './src/_generated/tokens',
  CONTRACTS_PATH: './src/_generated/contracts',
  ADDRESS_DARKLIST_PATH: './src/_generated/address-darklist',
  URL_DARKLIST_PATH: './src/_generated/url-darklist',
  URL_LIGHTLIST_PATH: './src/_generated/url-lightlist',
  GENERATED_FOLDER_PATH: './src/_generated',
  MASTER_FILE_PATH: './src/_generated/'
};
