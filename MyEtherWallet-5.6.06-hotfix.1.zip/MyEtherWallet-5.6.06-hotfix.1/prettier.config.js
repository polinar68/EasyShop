module.exports = {
  semi: true,
  singleQuote: true,
  trailingComma: 'none',
  arrowParens: 'avoid'
};
