const MEW_CX = 'mewcx';
const WEB = 'web';
export { MEW_CX, WEB };
