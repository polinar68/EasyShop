export { default } from './ConfirmCollectionModal';
