export { default } from './FifsBuyContainer';
