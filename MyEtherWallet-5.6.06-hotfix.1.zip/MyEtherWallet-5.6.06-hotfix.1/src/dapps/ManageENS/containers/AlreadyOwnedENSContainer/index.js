export { default } from './AlreadyOwnedENSContainer';
