export { default } from './PermanentRegistrationContainer';
