export { default } from './RegistrationInProgressContainer';
