export { default } from './NameForbiddenENSContainer';
