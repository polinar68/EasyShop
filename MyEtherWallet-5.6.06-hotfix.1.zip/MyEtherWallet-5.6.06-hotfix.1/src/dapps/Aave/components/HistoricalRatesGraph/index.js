export { default } from './HistoricalRatesGraph';
