export { default } from './RateModal';
