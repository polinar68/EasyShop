export { default } from './SummaryTable';
