export { default } from './SummaryTableMobile';
