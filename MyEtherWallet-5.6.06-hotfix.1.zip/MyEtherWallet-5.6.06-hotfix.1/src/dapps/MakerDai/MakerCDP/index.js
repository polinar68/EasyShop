import MakerCDP from '@/dapps/MakerDai/MakerCDP/MakerCDP';

export default MakerCDP;
