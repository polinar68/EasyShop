import CreateCDP from './CreateCDP';

export default CreateCDP;
