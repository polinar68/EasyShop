import ProxyMigrateCDP from './ProxyMigrateCDP';

export default ProxyMigrateCDP;
