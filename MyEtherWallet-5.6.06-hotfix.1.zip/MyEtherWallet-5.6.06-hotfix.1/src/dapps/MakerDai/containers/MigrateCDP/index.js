import MigrateCDP from './MigrateCDP';

export default MigrateCDP;
