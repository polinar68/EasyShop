import MigrateDai from './MigrateDai';

export default MigrateDai;
