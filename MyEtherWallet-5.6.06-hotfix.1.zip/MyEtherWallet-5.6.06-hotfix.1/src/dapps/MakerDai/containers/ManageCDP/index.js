import ManageCDP from './ManageCDP';

export default ManageCDP;
