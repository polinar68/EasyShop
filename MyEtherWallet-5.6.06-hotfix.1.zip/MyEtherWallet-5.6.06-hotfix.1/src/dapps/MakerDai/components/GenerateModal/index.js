export { default } from './GenerateModal';
