import SelectCdpEntry from './SelectCdpEntry';

export default SelectCdpEntry;
