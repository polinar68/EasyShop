<template>
  <div class="user-reminder-button">
    <img src="~@/assets/images/icons/acknowledge.png" />
    <p>{{ $t('common.tutorial') }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="scss" scoped>
@import 'UserReminderButton.scss';
</style>
