export { default } from './PageTitleComponent';
