export { default } from '@/layouts/InterfaceLayout/containers/SwapContainer/components/SwapWidget';
