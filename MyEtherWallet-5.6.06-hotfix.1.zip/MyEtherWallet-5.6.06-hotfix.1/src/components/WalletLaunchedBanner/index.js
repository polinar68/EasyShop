export { default } from './WalletLaunchedBanner';
