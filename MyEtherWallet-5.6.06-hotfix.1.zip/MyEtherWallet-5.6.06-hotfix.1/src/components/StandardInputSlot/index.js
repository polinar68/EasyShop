export { default } from './StandardInputSlot';
