export { default } from './InterfaceBottomText';
