<!doctype html>  

<!--[if IEMobile 7]><html <?php language_attributes(); ?> class="no-js iem7"><![endif]-->
<!--[if (gt IEMobile 7)|!(IEMobile)]><html <?php language_attributes(); ?> class="no-js"><![endif]-->
<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7 oldie"><![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 oldie"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><html <?php language_attributes(); ?> class="no-js"><![endif]-->
	
	<head>
		<meta charset="<?php bloginfo('charset'); ?>">
		
		<title><?php wp_title(); ?></title>
		
		<!-- Google Chrome Frame for IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<!-- mobile meta (hooray!) -->
		<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
		
		<!-- drop Google Analytics Here -->
		<!-- end analytics -->
		
		<!-- wordpress head functions -->
		<?php wp_head(); ?>
		<!-- end of wordpress head -->
	</head>
	<body <?php body_class(); ?>>
		<div data-role="page" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_GENERAL_THEME'); if(is_admin_bar_showing()) print 'style="margin-top:28px;"'; ?>>
			
			<div data-role="header" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME');?> data-id="page-header">
				<h1><?php bloginfo('name'); ?>
				<span class="ui-small-title"><?php bloginfo('description'); ?></span></h1>
				<a href="<?php echo esc_url(home_url()); ?>" data-icon="home" data-iconpos="notext" data-direction="reverse">Home</a>
				<a href="#search-page" data-icon="search" data-iconpos="notext" data-rel="dialog" data-transition="fade">Search</a>
			</div> <!-- end header -->
            <nav id="site-navigation" class="main-navigation" role="navigation">
                <?php 
                    // Adjust using Menus in Wordpress Admin 
                    $menu = wp_nav_menu(array( 
                        'container' => 'div',
                        'theme_location' => 'primary',                 // where it's located in the theme
                        'echo' => 0,
                        'menu_class' => 'nav-menu'
                    ));
                    print codepeople_light_navbar($menu);    
                ?>
            </nav>