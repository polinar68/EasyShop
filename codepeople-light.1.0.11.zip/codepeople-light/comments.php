<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains both current comments
 * and the comment form. The actual display of comments is
 * handled by a callback to twentyeleven_comment() which is
 * located in the functions.php file.
 */
			
?>
	<div id="comments" <?php if(post_password_required()):?> >
        <p class="nopassword"><?php _e( 'This post is password protected. Enter the password to view any comments.', 'codepeople-light-text' ); ?></p>
    </div><!-- #comments -->
    <?php
            /* Stop the rest of comments.php from being processed,
             * but don't kill the script entirely -- we still have
             * to fully load the template.
             */
            return;
        endif;
    ?> data-role="collapsible" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME');?> >
	

	<?php // You can start editing here -- including this comment! ?>
	<?php if(comments_open()):
			if ( have_comments() ) : ?>
				<h2 id="comments-title">
					<?php printf( _n( 'One thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', get_comments_number(), 'codepeople-light-text' ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' ); ?>
				</h2>
                <?php codepeople_light_comment_nav( 'nav-comment-above'); ?>
                <ul class="commentlist">
                    <?php
                            /* Loop through and list the comments. Tell wp_list_comments()
                             * to use codepeople_light_comment() to format the comments.
                             * If you want to overload this in a child theme then you can
                             * define codepeople_comment() and that will be used instead.
                             */
                            wp_list_comments( array( 'callback' => 'codepeople_light_comment' ) );
                    ?>
                </ul>
                <?php codepeople_light_comment_nav( 'nav-comment-below'); ?>
                <a data-role="button" data-icon="star" href="#comment-form" data-rel="dialog" onclick="loadCommentDialog(null, null, null, <?php print(the_ID()); ?>)"><?php _e('Leave a Reply', 'codepeople-light-text');?></a>
			<?php
			/* If there are no comments and comments are closed, let's leave a little note, shall we?
			 * But we don't want the note on pages or post types that do not support comments.
			 */
			else:
			?>
				<h2 id="comments-title">
					<?php printf( __( 'Thoughts on &ldquo;%s&rdquo;', 'codepeople-light-text' ), '<span>' . get_the_title() . '</span>' ); ?>
				</h2>
				<div id="comments-content">
					<?php	
					if ( ! comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) :
					?>
						<p class="nocomments"><?php _e( 'Comments are closed.', 'codepeople-light-text' ); ?></p>
					<?php 
					else:
					?>
						<a data-role="button" data-icon="star" href="#comment-form" data-rel="dialog" onclick="initializeCommentForm('#commentform');"><?php _e('Leave a Reply', 'codepeople-light-text');?></a>
					<?php
					endif; 
					?>
				</div>
			<?php endif; ?>
	
	<?php endif; ?>	
</div><!-- #comments -->
<div id="comment-form-tmp" style="display:none;">
	<?php comment_form(); ?>
</div>