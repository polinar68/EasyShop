<?php
/**
 * The template for displaying Category Archive pages.
 */
get_header(); 
?>

<div id="content" data-role="content">

<?php if ( have_posts() ) : ?>

	<header class="page-header">
		<h2 class="page-title"><?php
			printf( __( 'Category Archives: %s', 'codepeople-light-text' ), '<span>' . single_cat_title( '', false ) . '</span>' );
		?></h2>

		<?php
			$category_description = category_description();
			if ( ! empty( $category_description ) ):
				echo '<div data-role="collapsible" '.codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME').'>
						<h2>'.__('Description', 'codepeople-light-text').'</h2>';
				echo apply_filters( 'category_archive_meta', '<div class="category-archive-meta">' . $category_description . '</div>' );
				echo '</div>';
			endif;
		?>
	</header>

	<?php codepeople_light_content_nav( 'nav-above' ); ?>

	<?php /* Start the Loop */ ?>
	<ul data-role="listview" data-inset="true" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_LIST_THEME'); ?>>
	<?php while ( have_posts() ) : the_post(); ?>

		<?php get_template_part( 'subtemplate-list'); ?>

	<?php endwhile; ?>
	</ul>
	<?php codepeople_light_content_nav( 'nav-below' ); ?>

<?php else : ?>

	<article id="post-0" class="post no-results not-found">
		<header class="entry-header">
			<h2 class="entry-title"><?php _e( 'Nothing Found', 'codepeople-light-text' ); ?></h2>
		</header><!-- .entry-header -->

		<div class="entry-content">
			<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'codepeople-light-text' ); ?></p>
			<?php get_search_form(); ?>
		</div><!-- .entry-content -->
	</article><!-- #post-0 -->

<?php endif; ?>
<?php get_sidebar(); ?>
</div><!-- #content -->
<?php get_footer(); ?>
