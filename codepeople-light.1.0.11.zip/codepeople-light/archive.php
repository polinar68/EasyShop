<?php
/**
 * The template for displaying all audios.
 */

get_header(); ?>

<div id="content" data-role="content">

	<?php while ( have_posts() ) : the_post(); ?>

		<?php get_template_part( 'content', 'audio' ); ?>

		<?php comments_template( '', true ); ?>

	<?php endwhile; // end of the loop. ?>
	<?php get_sidebar(); // sidebar 1 ?>
</div><!-- #content -->

<?php get_footer(); ?>