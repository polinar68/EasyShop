<?php
/**
 * The template for displaying Video Posts
 */
 
global $content_width;
$content_width = 496;
$video_file = codepeople_light_media( $post->ID, 'video' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h2 class="entry-title"><?php the_title(); ?></h2>

		<?php if ( 'post' == get_post_type() ) : ?>
			<div class="entry-meta">
			<?php codepeople_light_posted_on(); ?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
		<div class="ui-media">
			<?php if ( ! empty( $video_file ) ) : ?>
			<video controls autobuffer id="video-player-<?php echo $post->ID; ?>" src="<?php echo esc_url($video_file); ?>" class="ui-video-player" onerror="removeVideo();">
			</video>
			<script type="text/javascript">
				function removeVideo(){
					if(jQuery){
						jQuery('[id="video-player-<?php echo $post->ID; ?>"]').remove();
					}
				}
				// Check if the video tag is supported and the video file be played
				var videoTag = document.createElement('video');
				if ( ! ( !! ( videoTag.canPlayType ))) {
					removeVideo();		
				}
				
			</script>
		<?php endif; ?>
		<?php
		add_filter( 'video_embed_html', 'codepeople_light_video_embed_html' ); // Support for VideoPress, YouTube, and Vimeo
		add_filter( 'oembed_result', 'codepeople_light_check_video_embeds', 10, 2 ); // Support auto-embeds videos via direct URL
		?>
		</div>
		<div class="ui-abstract">	
			<?php the_excerpt(); ?>
		</div>
			
		<?php get_template_part( 'subtemplate-meta' ); ?>
		<?php 
			$content = get_the_content(__("Read More", 'codepeople-light-text'));
			if(!empty($content)):
				$content = apply_filters('the_content', $content);
		?>	
			<div data-role="collapsible" data-collapsed="true"  <?php print codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME'); ?> >
				<h3><?php _e( 'Continue reading', 'codepeople-light-text' ); ?></h3>
				<?php print '<p>'.$content.'</p>'; ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'codepeople-light-text' ) . '</span>', 'after' => '</div>' ) ); ?>
			</div>
		<?php endif; ?>
	</div>	
</article>