<?php
 /**
 * Set and get global variables
 */
 function codepeople_light_get( $var_name ){
 		return ( isset( $GLOBALS[$var_name] ) ) ? $GLOBALS[$var_name] : '';
 } // codepeople_light_get
 
 function codepeople_light_set( $var_name, $value ){
 		$GLOBALS[$var_name] = $value;
 } // codepeople_light_set
 
 /**
 * Tell WordPress to run codepeople_light_setup() when the 'after_setup_theme' hook is run.
 */
add_action( 'after_setup_theme', 'codepeople_light_setup' );

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */

function codepeople_light_setup(){
    
    // Load translation files
    load_theme_textdomain( 'codepeople-light-text', get_template_directory() . '/languages' );	
        
    if( !is_admin() && !in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ) ) ){	
        /**
         * Initializing variables
         */
        
        // Load theme configuration
        $codepeople_light_options = get_option( 'codepeople-light-options' );

        $codepeople_light_general_theme = $codepeople_light_header_theme = $codepeople_light_footer_theme = $codepeople_light_navbar_theme = $codepeople_light_list_theme = 'default';
        
        if( isset( $codepeople_light_options ) ){
            if( isset( $codepeople_light_options['codepeople-light-general-theme'] ) ){
                $codepeople_light_general_theme = $codepeople_light_options['codepeople-light-general-theme'];
            }	
             
            if( isset( $codepeople_light_options['codepeople-light-header-theme'] ) ){
                $codepeople_light_header_theme   = $codepeople_light_options['codepeople-light-header-theme'];
            } 
            
            if( isset( $codepeople_light_options['codepeople-light-footer-theme'] ) ){
                $codepeople_light_footer_theme   = $codepeople_light_options['codepeople-light-footer-theme'];
            }
            
            if( isset( $codepeople_light_options['codepeople-light-navbar-theme'] ) ){
                $codepeople_light_navbar_theme   = $codepeople_light_options['codepeople-light-navbar-theme'];
            }
            
            if( isset( $codepeople_light_options['codepeople-light-list-theme'] ) ){
                $codepeople_light_list_theme   = $codepeople_light_options['codepeople-light-list-theme'];
            }
        }
        
        // Get related paths
        $codepeople_light_theme_path = get_template_directory_uri();
        $theme_path_length = strlen( $codepeople_light_theme_path );
        $codepeople_light_theme_path = ( '/' == $codepeople_light_theme_path[$theme_path_length-1] ) ? substr( $codepeople_light_theme_path, 0, $theme_path_length-1 ) : $codepeople_light_theme_path;
        $codepeople_light_theme_path .= ( false === strpos( $codepeople_light_theme_path, 'codepeople-light' ) ) ? '/codepeople-light' : ''; 
        
        codepeople_light_set( 'codepeople_light_theme_path', $codepeople_light_theme_path );
        // I18n
        load_plugin_textdomain( 'codepeople-light-text', false, $codepeople_light_theme_path. '/languages/' );
        
        // Populate global variables
        
        codepeople_light_set( 'CODEPEOPLE_LIGHT_GENERAL_THEME', ( 'default' != $codepeople_light_general_theme ) ? ' data-theme="'.$codepeople_light_general_theme.'" ' : '' );
        codepeople_light_set( 'CODEPEOPLE_LIGHT_HEADER_THEME' , ( 'default' != $codepeople_light_header_theme ) ? ' data-theme="'.$codepeople_light_header_theme.'" '  : '' );
        codepeople_light_set( 'CODEPEOPLE_LIGHT_FOOTER_THEME' , ( 'default' != $codepeople_light_footer_theme ) ? ' data-theme="'.$codepeople_light_footer_theme.'" '  : '' );
        codepeople_light_set( 'CODEPEOPLE_LIGHT_NAVBAR_THEME' , ( 'default' != $codepeople_light_navbar_theme ) ? $codepeople_light_navbar_theme  : ( ( $codepeople_light_general_theme != 'default' ) ? $codepeople_light_general_theme : 'c' ) );
        codepeople_light_set( 'CODEPEOPLE_LIGHT_LIST_THEME'   , ( 'default' != $codepeople_light_list_theme ) ? ' data-theme="'.$codepeople_light_list_theme.'" '    : '' );
        codepeople_light_set( 'CODEPEOPLE_LIGHT_CONTENT_THEME', ' data-content-theme="'.( ( 'default' != $codepeople_light_general_theme ) ? $codepeople_light_general_theme : 'c' ).'" ' );
    }
    
    // wp thumbnails (sizes handled in functions.php)
    add_theme_support( 'post-thumbnails' );

    // default thumb size   
    set_post_thumbnail_size( 624, 9999, true );

    // rss thingy           
    add_theme_support( 'automatic-feed-links' );
    
    // adding post format support
    add_theme_support( 'post-formats', array( 'aside', 'link', 'gallery', 'status', 'quote', 'image', 'audio' ) );	

    // registering wp3+ menus          
    register_nav_menus(                      
        array( 
            'primary' => __( 'The Main Menu', 'codepeople-light-text' ),   // main nav in header
            'footer-links' => __( 'Footer Links', 'codepeople-light-text' ) // secondary nav in footer
        )
    );
}// codepeople_light_setup
 

/**
* Tell WordPress to run codepeople_light_scripts() when the 'wp_enqueue_scripts' hook is run.
*/
add_action( 'wp_enqueue_scripts', 'codepeople_light_styles' );

function codepeople_light_styles(){
    wp_enqueue_style ( 'codepeople-light-jquerymobile-style', codepeople_light_get( 'codepeople_light_theme_path' ).'/base/jquery.mobile-1.2.0.min.css' );
    wp_enqueue_style ( 'codepeople-light-own-style', codepeople_light_get( 'codepeople_light_theme_path' ).'/style.css' );
        
}// codepeople_light_styles
 
add_action( 'wp_enqueue_scripts', 'codepeople_light_scripts' );
function codepeople_light_scripts(){
    /* We add some JavaScript to pages with the comment form
     * to support sites with threaded comments (when in use).
     */
    if ( is_singular() && get_option( 'thread_comments' ) )
        wp_enqueue_script( 'comment-reply' );
    
    wp_enqueue_script( 'codepeople-light-jquerymobile-script', codepeople_light_get( 'codepeople_light_theme_path' ).'/base/jquery.mobile-1.2.0.min.js', array( 'jquery' ) );
    wp_enqueue_script( 'codepeople-light-own-script', codepeople_light_get( 'codepeople_light_theme_path' ).'/js/codepeople-light.js', array( 'jquery' ) );
}// codepeople_light_scripts


$template_directory = get_template_directory();

/**
 * Load the theme configuration and related routines
 */
require_once $template_directory.'/core/config.theme.php';

/**
 * Load the media related routines, actions and filters
 */
require_once $template_directory.'/core/media.routines.php';

/**
 * Load comments related routines, actions and filters
 */
require_once $template_directory.'/core/comment.routines.php';
 
/**
 * Tell WordPress to run codepeople_light_register_sidebar() when widgets are initialized
 */
add_action( 'widgets_init', 'codepeople_light_register_sidebars' );

/**
 * Set the widgets inside a box
 */
function codepeople_light_register_sidebars(){
    global $wp_registered_sidebars;
    $codepeople_light_options = get_option( 'codepeople-light-options' );
    $codepeople_light_header_theme = ( isset( $codepeople_light_options ) && isset( $codepeople_light_options['codepeople-light-header-theme'] ) ) ? $codepeople_light_options['codepeople-light-header-theme'] : 'default';
    register_sidebar( array( 
        'id' => 'sidebar-1',
        'name' => 'Sidebar 1',
        'description' => 'The first (primary) sidebar.',
        'before_widget' => '<div id="%1$s" class="ui-widget %2$s" data-role="collapsible" data-collapsed="false" '.codepeople_light_get( 'CODEPEOPLE_LIGHT_CONTENT_THEME' ).codepeople_light_get( 'CODEPEOPLE_LIGHT_HEADER_THEME' ).'>',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="ui-widget-title">',
        'after_title' => '</h3>',
    ) );
}// codepeople_light_register_sidebars


/**
 * Tell WordPress to run codepeople_light_navbar() when navigation menu is loaded
 */
function codepeople_light_page_menu_args( $args ) {
	if ( ! isset( $args['show_home'] ) )
		$args['show_home'] = true;
	return $args;
}

add_filter( 'wp_page_menu_args', 'codepeople_light_page_menu_args' );
add_filter( 'wp_list_pages', 'codepeople_light_navbar', 10, 2 );
add_filter('wp_nav_menu_items', 'codepeople_light_navbar', 10, 2);

/**
 * Set the data-role attribute to "Navigate" menu
 */
function codepeople_light_navbar( $menu ) {
    $menu = str_replace( '<ul', '<ul class="ui-bar-'.codepeople_light_get( 'CODEPEOPLE_LIGHT_NAVBAR_THEME' ).'" ', $menu );	
    return $menu;    
}// codepeople_light_navbar


/** 
 * Tell WordPress to call codepeople_light_navbar_options() before display the navigation bar options
 */
add_filter( 'wp_nav_menu_items', 'codepeople_light_navbar_options' );

/** 
 * Set the data-theme attribute for each navigate menu's items
 */
function codepeople_light_navbar_options( $items ) {
    $items = str_replace( '<a ', '<a '.codepeople_light_get( 'CODEPEOPLE_LIGHT_NAVBAR_THEME' ).' ', $items );	
    return $items;    
}// codepeople_light_navbar_options

/**
 * Tell WordPress to call codepeople_light_link_replace before display the post content
 */
add_filter( 'the_content', 'codepeople_light_link_replace' );

function codepeople_light_link_replace( $content ){
    return str_replace( '<a ', '<a rel="external" ', $content );
}// codepeople_light_link_replace
 
/**
 * Display navigation to next/previous pages when applicable
 */
function codepeople_light_content_nav( $nav_id ) {
    global $wp_query;
    if ( $wp_query->max_num_pages > 1 ){
        $next = get_next_posts_link( __( 'Older', 'codepeople-light-text' ) );
        $prev = get_previous_posts_link( __( 'Newer', 'codepeople-light-text' ) ); 
        // Set the links as buttons
        $next = str_replace( '<a ', '<a data-icon="arrow-l" data-role="button"', $next );
        $prev = str_replace( '<a ', '<a data-icon="arrow-r" data-iconpos="right" data-role="button"', $prev );
        
        print '<center><nav id="'.$nav_id.'" data-role="controlgroup" data-type="horizontal">'.$next.$prev.'</nav></center><!-- #nav-above -->';
    }
}// codepeople_light_content_nav

/**
 * Display navigation to next/previous post when applicable
 */
function codepeople_light_post_nav( $nav_id, $gallery=false ) {
    $nav = '<center><nav id="'.esc_attr( $nav_id ).'" data-role="controlgroup" data-type="horizontal">';
    
    if($gallery){
        $post = get_post();
        $attachments = array_values( get_children( array( 'post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID' ) ) );
    
        foreach ( $attachments as $k => $attachment )
            if ( $attachment->ID == $post->ID )
                break;
    
        $n = $k + 1;
        $p = $k - 1;
        if ( isset( $attachments[ $p ] ) ) $prev = '?attachment_id='.$attachments[ $p ]->ID;
        if ( isset( $attachments[ $n ] ) ) $next = '?attachment_id='.$attachments[ $n ]->ID;
    }else{
        $next = get_next_post();
        $prev = get_previous_post(); 
    }
    
    // Set the links as buttons
    if( $prev ){
        $nav .= '<a data-role="button" data-icon="arrow-l" href="'.esc_url( ( ( $gallery ) ? $prev : get_permalink( $prev->ID ) ) ).'">';
        if( $gallery ){
            $nav .= __( 'Prev Image', 'codepeople-light-text' );
        }else{
            $nav .= __( 'Prev', 'codepeople-light-text' );
        }	
        $nav .= '</a>';
    }
    if( $next ){
        $nav .= '<a data-role="button" data-icon="arrow-r" data-iconpos="right" href="'.esc_url( ( ( $gallery ) ? $next : get_permalink( $next->ID ) ) ).'">';
        if( $gallery ){
            $nav .= __( 'Next Image', 'codepeople-light-text' );
        }else{
            $nav .= __( 'Next', 'codepeople-light-text' );
        }	
        $nav .= '</a>';
    }
    
    $nav .= '</nav></center>';
        
    print $nav.'<!-- #nav-above -->';
}// codepeople_light_post_nav

/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function codepeople_light_posted_on() {
    printf( __( '<span class="sep">Posted on </span><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s" pubdate>%4$s</time></a><span class="by-author"> <span class="sep"> by </span> <span class="author vcard"><a class="url fn n" href="%5$s" title="%6$s" rel="author">%7$s</a></span></span>', 'codepeople-light-text' ),
        esc_url( get_permalink() ),
        esc_attr( get_the_time() ),
        esc_attr( get_the_date( 'c' ) ),
        esc_html( get_the_date() ),
        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
        esc_attr( sprintf( __( 'View all posts by %s', 'codepeople-light-text' ), get_the_author() ) ),
        get_the_author()
    );
}// codepeople_light_posted_on

?>