CODEPEOPLE-LIGHT THEME
VERSION v1.0.11

Copyright (C) 2012 Team CodePeople - http://www.codepeople.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You may have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

You may also view the license online at http://www.gnu.org/licenses/gpl-2.0.html

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

Welcome to the CodePeople-Light theme.

CodePeople-Light is a theme based on jQueryMobile framework supported by the most important mobile devices on the market ( Go to "http://wordpress.dwbooster.com/themes/codepeople-light#devices" for a complete list of supported devices). CodePeople-Light theme avoids non-essential sections or graphics to reduce scrolling. The settings of CodePeople-Light theme allow to adapt your site's "look and feel" through a simple selection of colors for its main elements.

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

The quickest way to start customsing your theme is by changing the template parts. Anything that has 'content-' in the name is a template part used for respective post format, ie:

content-aside.php
content-audio.php
content-image.php
content-link.php
content-page.php
content-quote.php
content-single.php
content-video.php


These files just contain very simple content - not all the surrounding code. The previous files are loaded through get_template_part() from:

index
page
single
tag
archive
author
category

Some snippets of code are repeated in various files and we have decided to separate these codes in its own files and usign get_template_part() for loading.

subtemplate-list.php
subtemplate-meta.php 

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

== Changelog ==

= 1.0.11 =
* a change in the codepeople-light.js file that allows display the comments insertion  form.