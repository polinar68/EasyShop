<?php
/**
 * codepeople-light theme
 * http://wordpress.dwbooster.com
 *
 * Description: Actions, filters and routines for media treatment
 */
 
/**
 * Return the first audio file found for a post.
 *
 * @param int post_id ID for parent post
 * @return boolean|string Path to audio file
 */
function codepeople_light_media( $post_id, $type='audio' ) {
    global $wpdb;

    $first_attachment = get_permalink($wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_parent = %d AND post_type = 'attachment' AND INSTR(post_mime_type, '$type') ORDER BY menu_order ASC LIMIT 0,1", (int) $post_id ) ) );

    if ( ! empty( $first_attachment ) )
        return $first_attachment;

    return false;
}// codepeople_light_media

/**
 * Add extra markup to VideoPress embeds.
 *
 * @param string html Video content from VideoPress plugin.
 * @return string Updated content with extra markup.
 */
function codepeople_light_video_embed_html( $html ) {
    $html = '<div class="frame"><div class="ui-video-player">' . $html . '</div></div>';
    return $html;
}// codepeople_light_video_embed_html

/**
 * Add extra markup to auto-embedded videos.
 *
 * @param string html Content from the auto-embed plugin.
 * @param string url Link embedded in the post, used to determine if this is a video we want to filter.
 * @return string Updated content with extra markup.
 */
function codepeople_light_check_video_embeds( $html, $url ) {
    if ( false !== ( strstr( $url, 'youtube' ) ) || false !== ( strstr( $url, 'vimeo' ) ) )
        $html = codepeople_light_video_embed_html( $html );
    return $html;
}// codepeople_light_check_video_embeds	
?>