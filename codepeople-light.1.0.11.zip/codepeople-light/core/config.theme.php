<?php
/**
 * codepeople-light theme
 * http://wordpress.dwbooster.com
 *
 * Description: CodePeople Light theme configuration
 */
 
define('CODEPEOPLE_LIGHT_JS_DIR', get_template_directory_uri().'/js');
define('CODEPEOPLE_LIGHT_IMAGE_DIR', get_template_directory_uri().'/images');

$codepeople_light_themes = array('default', 'a', 'b', 'c', 'd', 'e');

add_action( 'admin_enqueue_scripts', 'codepeople_light_admin_scripts' );
function codepeople_light_admin_scripts(){
	// Load the administration script
	wp_enqueue_script('codepeople-light-admin-script', CODEPEOPLE_LIGHT_JS_DIR.'/codepeople-light.admin.js', array('jquery'));
	wp_localize_script('codepeople-light-admin-script', 'config', array(
			'image_path'  	=> CODEPEOPLE_LIGHT_IMAGE_DIR
		));

} // End codepeople_light_admin_scripts
 
/**
 * Set the menu option for theme's setup page
 */
add_action('admin_menu', 'codepeople_light_add_admin_menu');
function codepeople_light_add_admin_menu() {
	// Create the new top-level Menu
	add_theme_page ('CodePeople Light', 'CodePeople Light', 'edit_theme_options','codepeople-light', 'codepeople_build_option_interface');
} // codepeople_light_add_admin_menu

function codepeople_light_validation($value){
	return (preg_match('/^(default)|[abcde]$/', $value)) ? $value : 'default';
} // End codepeople_light_validation

/**
 * Create the interface of theme setup page
 */
function codepeople_build_option_interface(){ 
	$codepeople_light_options = get_option('codepeople-light-options');
	
	$codepeople_light_general_theme = $codepeople_light_header_theme = $codepeople_light_footer_theme = $codepeople_light_navbar_theme = $codepeople_light_list_theme = 'default';
	
	if(isset($codepeople_light_options)){
		if(isset($codepeople_light_options['codepeople-light-general-theme'])){
			$codepeople_light_general_theme   = $codepeople_light_options['codepeople-light-general-theme'];
		}	
		 
		if(isset($codepeople_light_options['codepeople-light-header-theme'])){
			$codepeople_light_header_theme   = $codepeople_light_options['codepeople-light-header-theme'];
		} 
		
		if(isset($codepeople_light_options['codepeople-light-footer-theme'])){
			$codepeople_light_footer_theme   = $codepeople_light_options['codepeople-light-footer-theme'];
		}
		
		if(isset($codepeople_light_options['codepeople-light-navbar-theme'])){
			$codepeople_light_navbar_theme   = $codepeople_light_options['codepeople-light-navbar-theme'];
		}
		
		if(isset($codepeople_light_options['codepeople-light-list-theme'])){
			$codepeople_light_list_theme   = $codepeople_light_options['codepeople-light-list-theme'];
		}
	}
	
	if(isset($_POST['codepeople-theme-design-submit']) && wp_verify_nonce($_POST['codepeople-theme-design-submit'], __FILE__)){
			
		echo '<div class="updated"><p><strong>'.__("Settings Updated").'</strong></div>';
		
		$codepeople_light_general_theme = codepeople_light_validation($_POST['codepeople-light-general-theme']);
		$codepeople_light_header_theme  = codepeople_light_validation($_POST['codepeople-light-header-theme']);
		$codepeople_light_footer_theme  = codepeople_light_validation($_POST['codepeople-light-footer-theme']);
		$codepeople_light_navbar_theme  = codepeople_light_validation($_POST['codepeople-light-navbar-theme']);
		$codepeople_light_list_theme    = codepeople_light_validation($_POST['codepeople-light-list-theme']);
		
		$codepeople_light_options = array(
			'codepeople-light-general-theme' => $codepeople_light_general_theme,
			'codepeople-light-header-theme'  => $codepeople_light_header_theme,
			'codepeople-light-footer-theme'  => $codepeople_light_footer_theme,
			'codepeople-light-navbar-theme'  => $codepeople_light_navbar_theme,
			'codepeople-light-list-theme'    => $codepeople_light_list_theme
		);
		
		update_option('codepeople-light-options', $codepeople_light_options);
	}
	
	echo '<div class="wrap">
				<form method="post" action="'.esc_url($_SERVER['REQUEST_URI']).'">
					<h2>Theme Configuration</h2>
					<table class="form-table" style="width:auto;">
						<tbody>
							<tr valign="top">
								<th scope="row">
									'.__('General theme design', 'codepeople-light-text').'</label>
								</th>
								<td colspan="2">
									<table class="form-table">
										<tr>
											<td>
												<select name="codepeople-light-general-theme" onchange="changeImage(this, \'#codepeople-light-general-theme\')">
													'.codepeople_light_print_options($codepeople_light_general_theme, true).'
												</select>
											</td>
										</tr>
										<tr>		
											<td>'.codepeople_light_print_image($codepeople_light_general_theme).'</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row">
									'.__('Particular design for Headers', 'codepeople-light-text').'</label>
								</th>
								<td>
									<select name="codepeople-light-header-theme" onchange="changeImage(this, \'#codepeople-light-header-theme\', \'element_\')">
										'.codepeople_light_print_options($codepeople_light_header_theme).'
									</select>
								</td>
								<td>'.codepeople_light_print_image($codepeople_light_header_theme, 'header').'</td>
							</tr>
							<tr valign="top">
								<th scope="row">
									'.__('Particular design for Footers', 'codepeople-light-text').'</label>
								</th>
								<td>
									<select name="codepeople-light-footer-theme" onchange="changeImage(this, \'#codepeople-light-footer-theme\', \'element_\')">
										'.codepeople_light_print_options($codepeople_light_footer_theme).'
									</select>
								</td>
								<td>'.codepeople_light_print_image($codepeople_light_footer_theme, 'footer').'</td>
							</tr>
							<tr valign="top">
								<th scope="row">
									'.__('Particular design for Nav Bars', 'codepeople-light-text').'</label>
								</th>
								<td>
									<select name="codepeople-light-navbar-theme" onchange="changeImage(this, \'#codepeople-light-navbar-theme\', \'element_\')">
										'.codepeople_light_print_options($codepeople_light_navbar_theme).'
									</select>
								</td>
								<td>'.codepeople_light_print_image($codepeople_light_navbar_theme, 'navbar').'</td>
							</tr>
							<tr valign="top">
								<th scope="row">
									'.__('Particular design for Lists', 'codepeople-light-text').'</label>
								</th>
								<td>
									 <select name="codepeople-light-list-theme" onchange="changeImage(this, \'#codepeople-light-list-theme\', \'element_\')">
										'.codepeople_light_print_options($codepeople_light_list_theme).'
									</select>
								</td>
								<td>'.codepeople_light_print_image($codepeople_light_list_theme, 'list').'</td>
							</tr>
						</tbody>
					</table>';
	echo '<input type="hidden" name="codepeople-theme-design-submit" value="' . wp_create_nonce(__FILE__) . '" />';
						
					
	echo '				
					<div class="submit"><input type="submit" class="button-primary" value="'.__('Update Settings', 'codepeople-light-text').'" /></div>
				</form>
			</div>';
} // codepeople_build_option_interface

function codepeople_light_print_options($value, $general = false){
	global $codepeople_light_themes;
	$result = '';
	foreach ($codepeople_light_themes as $theme){
		$result .= '<option value="'.esc_attr($theme).'" '.(($value == $theme) ? 'selected' : '').' >';
		if($theme == 'default'){
			$result .= ($general) ? __('Default theme', 'codepeople-light-text') : __('Inherited from general', 'codepeople-light-text');
		}else{
			$result .= __('Theme ', 'codepeople-light-text').strtoupper($theme);
		}
		$result .= '</option>';
	}
	
	return $result;
} // codepeople_light_print_options

function codepeople_light_print_image($value, $prefix = ''){
	if($value == 'default' && !empty($prefix)){
		$result = '<img id="codepeople-light-'.$prefix.'-theme" src="'.esc_url(CODEPEOPLE_LIGHT_IMAGE_DIR).'/empty.png">';
	}else{
		$result = '<img id="codepeople-light-'.((!empty($prefix)) ? $prefix : 'general').'-theme" src="'.esc_url(CODEPEOPLE_LIGHT_IMAGE_DIR).'/'.((!empty($prefix)) ? 'element_' : '').$value.'.png">';
	}
	return $result;
} // codepeople_light_print_image
?>