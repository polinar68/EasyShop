<?php
/**
 * codepeople-light theme
 * http://wordpress.dwbooster.com
 *
 * Description: Actions, filters and routines for comments treatment
 */
 
/**
 * Tell WordPress to call codepeople_light_reply_link() before display the reply links in comments
 */
add_filter('comment_reply_link', 'codepeople_light_reply_link');

/** 
 * Modify the "Reply" link in comments. The addComment.moveForm is replaced by loadCommentDialog, the anchor is converted in a jquerymobile button
 */ 
function codepeople_light_reply_link( $link ){
    $link = str_replace( array( '<a', 'addComment.moveForm' ), array( '<a data-inline="true" data-role="button" data-icon="arrow-d" data-rel="dialog"', 'loadCommentDialog' ), $link );
    return $link;
}// codepeople_light_reply_link

/**
 * Tell WordPress to call codepeople_light_redirect after insert a new comment
 */
add_filter( 'comment_post_redirect', 'codepeople_light_redirect' );	

/** 
 * It is called to redirect the webpage after insert a new comment
 */
function codepeople_light_redirect ( $location, $comment=null ){
    $parts = explode( '#', $location );
    return $parts[0];
}// codepeople_light_redirect

/**
 * Display navigation to next/previous comments when applicable
 */
function codepeople_light_comment_nav( $nav_id ) {
    if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through
            $next = get_next_comments_link( __( 'Newer', 'codepeople-light-text' ) );
        $prev = get_previous_comments_link( __( 'Older', 'codepeople-light-text' ) ); 
        // Set the links as buttons
        $next = str_replace( '<a', '<a data-icon="arrow-r" data-iconpos="right" data-role="button"', $next );
        $prev = str_replace( '<a', '<a data-icon="arrow-l" data-role="button"', $prev );
        
        print '<center><nav id="'.$nav_id.'" data-role="controlgroup" data-type="horizontal">'.$prev.$next.'</nav></center><!-- #nav-above -->';
    endif; // check for comment navigation
}// codepeople_light_comment_nav

/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own codepeople_light_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
function codepeople_light_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
		?>
			<li class="post pingback">
				<p><?php _e( 'Pingback:', 'codepeople-light-text' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( 'Edit', 'codepeople-light-text' ), '<span class="edit-link">', '</span>' ); ?></p>
		<?php
			break;
		default :
		?>
		<li <?php comment_class(); ?> id="li-comment-<?php esc_attr( comment_ID() ); ?>">
			<article id="comment-<?php esc_attr( comment_ID() ); ?>" class="comment ui-corner-all ui-shadow comment-content">
				<footer class="comment-meta">
					<div class="comment-author vcard">
						<?php
							$avatar_size = 68;
							if ( '0' != $comment->comment_parent )
								$avatar_size = 39;

							echo get_avatar( $comment, $avatar_size );

							/* translators: 1: comment author, 2: date and time */
							printf( __( '%1$s on %2$s <span class="says">said:</span>', 'codepeople-light-text' ),
								sprintf( '<span class="fn">%s</span>', get_comment_author_link() ),
								sprintf( '<a href="%1$s"><time pubdate datetime="%2$s">%3$s</time></a>',
									esc_url( get_comment_link( $comment->comment_ID ) ),
									get_comment_time( 'c' ),
									/* translators: 1: date, 2: time */
									sprintf( __( '%1$s at %2$s', 'codepeople-light-text' ), get_comment_date(), get_comment_time() )
								)
							);
						?>

						<?php edit_comment_link( __( 'Edit', 'codepeople-light-text' ), '<span class="edit-link">', '</span>' ); ?>
					</div><!-- .comment-author .vcard -->

					<?php if ( $comment->comment_approved == '0' ) : ?>
						<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'codepeople-light-text' ); ?></em>
						<br />
					<?php endif; ?>

				</footer>

				<div class="comment-content"><?php comment_text(); ?></div>

				<div class="reply">
					<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply', 'codepeople-light-text' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
				</div><!-- .reply -->
			</article><!-- #comment-## -->
	<?php
			break;
	endswitch;
	?>
	</li>
	<?php
}// codepeople_light_comment()
?>