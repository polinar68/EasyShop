<?php
/**
 * The Template for displaying all single posts.
 */

get_header(); ?>

<div id="content" data-role="content">
	<?php while ( have_posts() ) : the_post(); ?>
		<?php codepeople_light_post_nav( 'nav-above', true); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">
				<h2 class="entry-title"><?php the_title(); ?></h2>
		
				<?php
					$metadata = wp_get_attachment_metadata();
					printf( __( '<div class="entry-meta"><span class="meta-prep meta-prep-entry-date">Published </span> <span class="entry-date"><abbr class="published" title="%1$s">%2$s</abbr></span> at <a href="%3$s" rel="external" title="Link to full-size image">%4$s &times; %5$s</a> in <a href="%6$s" title="Return to %7$s" rel="gallery">%8$s</a></div><!-- .entry-meta -->'),
										esc_attr( get_the_time() ),
										get_the_date(),
										esc_url( wp_get_attachment_url() ),
										$metadata['width'],
										$metadata['height'],
										esc_url( get_permalink( $post->post_parent ) ),
										esc_attr( strip_tags( get_the_title( $post->post_parent ) ) ),
										get_the_title( $post->post_parent )
									);
				?>
				<?php if ( ! empty( $post->post_excerpt ) ) : ?>
					<div class="entry-caption">
						<?php the_excerpt(); ?>
					</div>
				<?php endif; ?>
			</header><!-- .entry-header -->
		
			<div class="entry-content">
				<div class="ui-grid-b">
					<?php
						echo wp_get_attachment_image( $post->ID, 1024 ); // filterable image width with 1024px limit for image height.
					?>	
				</div><!-- .ui-grid-b -->
				<div class="entry-description">
					<?php the_content(__("Read More", 'codepeople-light-text')); ?>
					<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'codepeople-light-text' ) . '</span>', 'after' => '</div>' ) ); ?>
				</div><!-- .entry-description -->	
			</div><!-- .entry-content -->
			<footer class="entry-meta">
			<?php get_template_part( 'subtemplate-meta' ); ?>
			</footer><!-- .entry-meta -->
		</article><!-- #post-<?php the_ID(); ?> -->
		<?php comments_template( '', true ); ?>
	<?php endwhile; // end of the loop. ?>
	<?php get_sidebar(); // sidebar 1 ?>
</div><!-- #content -->

<?php get_footer(); ?>