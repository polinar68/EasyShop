<?php 
get_header();
?>
<div data-role="content">

	<?php if (have_posts()) : ?>
	<?php codepeople_light_content_nav(  'nav-above' ); ?>
	<!-- Set the posts as list -->
	<ul data-role="listview" data-inset="true" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_LIST_THEME');?>>
	<?php while (have_posts()) : the_post(); ?>
		<?php get_template_part( 'subtemplate-list' ); ?>
	<?php endwhile; ?>
	</ul>
	<!-- End the posts list -->
	<?php codepeople_light_content_nav(  'nav-below' ); ?>
	<?php else : ?>
					    
		<article id="post-not-found">
			<header class="article-header">
				<h2><?php _e("Oops, Post Not Found!", "codepeople-light-text"); ?></h2>
			</header>
			<section class="post-content">
				<p><?php _e("Uh Oh. Something is missing. Try double checking things.", "codepeople-light-text"); ?></p>
			</section>
		</article>
					
	<?php endif; ?>
	<?php get_sidebar(); // sidebar 1 ?>
</div> <!-- end #content -->

<?php get_footer(); ?>
