            <nav id="footer-navigation" class="footer-navigation" role="navigation">
                <?php 
                    // Adjust using Menus in Wordpress Admin 
                    $footer_menu = wp_nav_menu(array( 
                        'container' => 'div',
                        'theme_location' => 'footer-links',                 // where it's located in the theme
                        'echo' => 0,
                        'menu_class' => 'nav-menu'


                    ));
                    print codepeople_light_navbar($footer_menu);    
                ?>
            </nav>

            <div data-role="footer" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_FOOTER_THEME'); ?> data-id="page-footer">
				<h4>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>.</h4>
			</div> <!-- end footer -->
		
		</div> <!-- end data-role=page of main page -->
		
		<div data-role="page" id="search-page" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_GENERAL_THEME'); ?>>
			<div data-role="header" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME'); ?>><h1><?php _e('Search for:', 'codepeople-light-text'); ?></h1></div>
			<div data-role="content">
			<?php 
				get_search_form();
			?>
			</div>
		</div> <!-- end data-role=page of search dialog -->
		
		<div data-role="page" id="comment-form" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_GENERAL_THEME'); ?>>
			<div data-role="header" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME'); ?>><h1>&nbsp;</h1></div>
			<div data-role="content">
			<!-- The actual comment form will be displayed here -->
			</div>
		</div>
		
		<?php wp_footer(); // js scripts are inserted using this function ?>
	</body>

</html> <!-- end page. what a ride! -->