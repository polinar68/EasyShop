<?php
/**
 * The template for displaying posts in the Quote Post Format on index and archive pages
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php if ( 'post' == get_post_type() ) : ?>
			<div class="entry-meta">
			<?php codepeople_light_posted_on(); ?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
		<div class="ui-quote">
			<?php 
				$content = get_the_content(__("Read More", 'codepeople-light-text'));
				$content = apply_filters('the_content', $content);
				print '<p>"'.$content.'"</p>';
			?>
		</div>
		<div class="ui-quote-title">
			[<?php the_title(); ?>]
		</div>
		<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'codepeople-light-text' ) . '</span>', 'after' => '</div>' ) ); ?>
		<footer class="entry-meta">
		<?php get_template_part( 'subtemplate-meta' ); ?>
		</footer><!-- .entry-meta -->
		
	</div><!-- .entry-content -->
</article><!-- #post-<?php the_ID(); ?> -->