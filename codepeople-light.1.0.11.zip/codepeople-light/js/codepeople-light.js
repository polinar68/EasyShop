/**
 * codepeople-light
 * http://wordpress.dwbooster.com
 */

// Global variable for bookmark processing
var codepeople_light_bookmark;
	

(function ($){
	/************* PROCESSING LINKS WITH BOOKMARKS *************/
	
	/*
	 * jQueryMobile use the bookmarks for load pages in multi-pages template
	 * is require treat the bookmarks for myself.
	 */
	function extractBookmarks(parent){
		$('a', parent).each(function(){
			var e = $(this),
				h = e.attr('href'),
				i = h.indexOf('#'),
				a = /(wp-admin|wp-login)/i.test(h);
			
			if(a){	
					e.attr('data-ajax', false);
			}else if(i != -1){
				var b = h.substr(i+1);
				
				if(i > 0){
					h = h.substr(0, i);
					e.attr({'href': h, 'bookmark': b});
					
				}else if(i == 0){
					// Check the existence of page with id equal to anchor href
					if($('.ui-page[id="'+b+'"]').length){
						return;
					}else{
						if($(b).length){
							$.mobile.silentScroll($(b).offset().top);
						}
					}
				}
			}	
		});
	}; // extractBookmarks
	
	/*
	 *  If the globar variabe codepeople_light_bookmark has a value,
	 *  the webpage must to jump to the bookmark
	 */
	function jumpToBookmark(){
		if(codepeople_light_bookmark){
			$('[id="'+codepeople_light_bookmark+'"]').each(function(){
				var top = $(this).offset().top;
				if(top){
					$.mobile.silentScroll(top); // Move to bookmark
					return;
				}
			});
		}
	}; // jumpToBookmark
	
	/************* PROCESSING DIALOG FOR COMMENTS INSERTION  *************/
	
	/*
	 * Move the title of comment form to the correct place
	 */
	function setCommentDialogTitle(){
		var form_header = $('#comment-form [data-role="content"] #reply-title');
		if(form_header.length){
			$('#comment-form [data-role="header"] h1').html(form_header.html());
			form_header.remove();
		}
	}; // setCommentDialogTitle
	
	/*
	 * Load the comment dialog
	 * loadCommentDialog replace the addComment.moveForm in "Reply" links , 
	 * some parameters are not used but are present because exists in the original routine
	 */
	function loadCommentDialog(commId, parentId, respondId, postId){
		var parent 	= $('#comment_parent'),
			post   	= $('#comment_post_ID');

		initializeCommentForm('#commentform'); // Remove previous data
		if (postId) post.val(postId);
		if (parentId) parent.val(parentId);	
		$('#comment').focus();
	}; // loadCommentDialog
	window['loadCommentDialog'] = loadCommentDialog; // The loadCommentDialog will be public out of clousure
	
	/*
	 * Set the "Reply" links to open the insertion comment dialog
	 */
	function commentReplyLink(){
		$('.comment-reply-link').each(function(){
			$(this).attr('href', '#comment-form');
		});
	}; // commentReplyLink	
		
	
	/*
	 * Reset the form fields and set the AJAX to false
	 */
	window['initializeCommentForm'] = function(formId){
		setTimeout(function(){
			var form = $('[id="comment-form-tmp"] '+formId);
			if(form.length){
				$('[id="comment-form"]').find('[data-role="content"]').empty().append(form.clone());
				
				// Intercept the comment form's submit, post the comment and reload the comments list 
				$('[id="comment-form"] form').bind('submit', function(evt){
					var e = $(this),
						comment_form = e.parents('[id="comment-form"]');

					evt.preventDefault();
					evt.stopPropagation();
					$.mobile.showPageLoadingMsg();
					$.ajax(
						{
							type 		: 'POST',
							cache 		: false,
							data 		: e.serialize(),
							dataType 	: 'html',
							url			: e.attr('action'), 
							error		: function(data){
								$.mobile.hidePageLoadingMsg();
								//Remove excessive code
								var err	= 'Error',
									d 	= data.responseText.substr(data.responseText.indexOf('<p>'));
								d = d.substr(0, d.indexOf('</p>')+4);
								
								if(d.length){
									err = d;
								}
								$('[id="comment-form"]').find('.ui-error').remove().end().find('[data-role="content"]').prepend('<div class="ui-error">'+err+'</div>');
							},
							success		: function(data){
								$.mobile.hidePageLoadingMsg();
								comment_form.bind('pagehide', function(){
									var d = $(data),
										comments_content  				= $('[id="comments-content"]').filter(':visible'),
										loaded_comments_content 		= d.find('[id="comments-content"]'),
										comments_section_title 			= $('[id="comments-title"]:visible .ui-btn-text'),
										loaded_comments_section_title 	= d.find('[id="comments-title"]');

									if(comments_content.length && loaded_comments_content.length) // Load the new comment list	
										comments_content.html(loaded_comments_content.html());
									
									// Set the correct title of comments section
									if(comments_section_title.length && loaded_comments_section_title.length){	
										comments_section_title.html(loaded_comments_section_title.html());
									}	
							
									$(document).trigger('pageshow');
							
									comments_content.trigger('create'); // Load the jQueryMobile styles and render the widgets
									comment_form.unbind('pagehide'); // Remove the pagehide event
							
									// Open the collapsible comments container
									$('#comments').trigger('expand');
								}); // pagehide event
								
								comment_form.dialog('close');
							}
						}	
					);
					return false;
				});
			}else{
				$('[id="comment-form"]').find('[data-role="content"]').html($('[id="comment-form-tmp"]').html());
			}
		},500);	
	};
	
	/************* GENERAL EVENTS AND ENTRY POINT OF SCRIPT EXECUTION *************/
	
	$(document).bind('pageshow', function(){
		
		// Process all bookmarks in page
		extractBookmarks($(document));
		jumpToBookmark();
		
		// Set the title of comment form to the correct place
		setCommentDialogTitle();
		
		//  Transform the comment reply buttons
		commentReplyLink();
	}).bind('ready', function(){
		// Show submenu
		$('[data-role="navbar"] ul.menu').find('li').bind('mouseover focusin', function(){
			$(this).children('.sub-menu').show();
		}).bind('mouseout focusout', function(evt){
			$(this).children('.sub-menu').hide();
		});
		
		// Intercept all links for load the correct bookmark
		$('a').live('click', function(evt){
			var e = $(this);
			codepeople_light_bookmark = e.attr('bookmark');
		});
		
		// Intercept the Next/Previous comments navigation buttons
		$('a[bookmark="comments"]').live('click', function(evt){
			var comments_content = $(this).parents('#comments-content');
			if(comments_content.length){
				evt.stopPropagation();
				evt.preventDefault();
				var e =$(this);
				
				// Load only the snippet of code for comments
				$.mobile.showPageLoadingMsg();
				comments_content.load(e.attr('href')+' #comments-content', function(){
					$.mobile.hidePageLoadingMsg();
					$(document).trigger('pageshow');
					$(this).trigger('create'); // Load the jQueryMobile styles and render the widgets
				});
				}	
		});
	});	
})(jQuery);