<?php
/**
 * The template for displaying 404 pages (Not Found).
 */
get_header(); 
?>

<div id="content" data-role="content">

	<article id="post-0" class="post error404 not-found">
		<header class="entry-header">
			<h2 class="entry-title"><?php _e( 'This is somewhat embarrassing, isn&rsquo;t it?', 'codepeople-light-text' ); ?></h2>
		</header>

		<div class="entry-content">
			<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching, or one of the links below, can help.', 'codepeople-light-text' ); ?></p>

			<?php the_widget( 	'WP_Widget_Recent_Posts', 
								array( 
									'number' => 10,
								), 
								array( 
									'before_widget'=> '<div data-role="collapsible"  '.codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').' class="ui-recent-posts" '.codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME').'>',
									'after_widget' => '</div>',
									'widget_id' => '404' 
								)
							); 
			?>

			<div class="widget" data-role="collapsible" <?php print codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME'); print codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME');?> >
				<h2 class="widgettitle"><?php _e( 'Most Used Categories', 'codepeople-light-text' ); ?></h2>
				<div class="ui-widgetcontent">
					<ul>
					<?php wp_list_categories( array( 'orderby' => 'count', 'order' => 'DESC', 'show_count' => 1, 'title_li' => '', 'number' => 10 ) ); ?>
					</ul>
				</div>	
			</div>

			<?php
			/* translators: %1$s: smilie */
			$archive_content = '<p>' . sprintf( __( 'Try looking in the monthly archives. %1$s', 'codepeople-light-text' ), convert_smilies( ':)' ) ) . '</p>';
			the_widget( 'WP_Widget_Archives', 
						array('count' => 0 , 'dropdown' => 1 ), 
						array( 
							'after_title' => '</h2>'.$archive_content,
							'before_widget'=> '<div data-role="collapsible"  '.codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME').'>',
							'after_widget' => '</div>'
						) 
					);
			?>

			<?php the_widget( 	'WP_Widget_Tag_Cloud', 
								array(), 
								array(
									'before_widget'=> '<div data-role="collapsible"  '.codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME').'>',
									'after_widget' => '</div>'
								) 
							); 
			?>

		</div><!-- .entry-content -->
	</article><!-- #post-0 -->

</div><!-- #content -->

<?php get_footer(); ?>