<?php
/**
 * The Template for displaying all single posts.
 */

get_header(); ?>
<div id="primary" class="site-content">
    <div id="content" data-role="content">
        <?php while ( have_posts() ) : the_post(); ?>
            <?php codepeople_light_post_nav( 'nav-above'); ?>
            <?php 
                $format = get_post_format();
                if ( '' != locate_template( array('content-'.$format.'.php'), false, false ) ) {
                    get_template_part( 'content', get_post_format() ); 
                }else{
                    get_template_part( 'content', 'single' ); 
                }
                
            ?>
            <?php comments_template( '', true ); ?>
        <?php endwhile; // end of the loop. ?>
        <?php get_sidebar(); // sidebar 1 ?>
    </div><!-- #content -->
</div>
<?php get_footer(); ?>