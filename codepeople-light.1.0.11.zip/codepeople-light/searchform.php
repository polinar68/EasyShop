<form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>">
        <input type="search" value="" name="s" id="s" value="<?php esc_attr(get_search_query());?>" placeholder="<?php _e('Search the Site...', 'codepeople-light-text');?>" />
        <input type="submit" id="searchsubmit" value="Search" />
</form>
