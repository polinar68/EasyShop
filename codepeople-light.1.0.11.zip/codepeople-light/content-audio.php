<?php
/**
 * The template for displaying Audio Posts
 */

$audio_file = codepeople_light_media( $post->ID );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h2 class="entry-title"><?php the_title(); ?></h2>

		<?php if ( 'post' == get_post_type() ) : ?>
			<div class="entry-meta">
			<?php codepeople_light_posted_on(); ?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
		<div class="ui-media">
		<?php 
		if ( has_post_thumbnail() ) :
			$album_image = wp_get_attachment_image( get_post_thumbnail_id()); ?>
			<?php echo $album_image; ?>
		<?php endif; ?>
		
		<?php if ( ! empty( $audio_file ) ) : ?>
			<audio controls autobuffer id="audio-player-<?php echo $post->ID; ?>" src="<?php echo $audio_file; ?>" class="ui-audio-player" onerror="removeAudio();">
			</audio>
			<script type="text/javascript">
				function removeAudio(){
					if(jQuery){
						jQuery('[id="audio-player-<?php echo $post->ID; ?>"]').remove();
					}
				}
				// Check if the audio tag is supported and the audio file be played
				var audioTag = document.createElement('audio');
				if ( ! ( !! ( audioTag.canPlayType ) ) ) {
					removeAudio();		
				}
			</script>
		<?php endif; ?>
		</div>
		<div class="ui-abstract">	
			<?php the_excerpt(); ?>
		</div>
		<?php get_template_part( 'subtemplate-meta' ); ?>
		<?php 
			$content = get_the_content(__("Read More", 'codepeople-light-text'));
			if(!empty($content)):
				$content = apply_filters('the_content', $content);
		?>	
			<div data-role="collapsible" data-collapsed="true"  data-content-theme="c" >
				<h3><?php _e( 'Continue reading', 'codepeople-light-text' ); ?></h3>
				<?php print '<p>'.$content.'</p>'; ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'codepeople-light-text' ) . '</span>', 'after' => '</div>' ) ); ?>
			</div>
		<?php endif; ?>
	</div><!-- .entry-content -->
</article>