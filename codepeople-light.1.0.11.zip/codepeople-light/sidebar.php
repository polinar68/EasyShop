<?php 
$codepeople_light_printed = false;
for($i = 1; $i < 10; $i++):
	if ( is_dynamic_sidebar( 'sidebar-'.$i ) ):
		if(!$codepeople_light_printed):
			$codepeople_light_printed = true;
?>	
			<div id="sidebar"  data-role="collapsible" data-collapsed="true"  <?php print codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME');?> >
			<h3><?php _e('More Options', 'codepeople-light-text')?></h3>
<?php	
		endif;
		dynamic_sidebar( 'sidebar-'.$i ); ?>
<?php endif; 
endfor;
if($codepeople_light_printed):
?>
		</div>
<?php
endif;
?>
