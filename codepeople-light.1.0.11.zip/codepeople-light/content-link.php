<?php
/**
 * The template for displaying posts in the Link Post Format on index and archive pages
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h2 class="entry-title"><a href="<?php esc_url(the_permalink()); ?>" title="<?php printf( esc_attr(__( 'Permalink to %s', 'codepeople-light-text' )), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<?php if ( 'post' == get_post_type() ) : ?>
			<div class="entry-meta">
			<?php codepeople_light_posted_on(); ?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
		<?php get_template_part( 'subtemplate-meta' ); ?>
		<?php 
			$content = get_the_content(__("Read More", 'codepeople-light-text'));
			if(!empty($content)):
				$content = apply_filters('the_content', $content);
		?>	
			<div data-role="collapsible" data-collapsed="true"  <?php print codepeople_light_get('CODEPEOPLE_LIGHT_CONTENT_THEME').codepeople_light_get('CODEPEOPLE_LIGHT_HEADER_THEME'); ?> >
				<h3><?php _e( 'Continue reading', 'codepeople-light-text' ); ?></h3>
				<?php print '<p>'.$content.'</p>'; ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', 'codepeople-light-text' ) . '</span>', 'after' => '</div>' ) ); ?>
			</div>
		<?php endif; ?>
	</div><!-- .entry-content -->
</article><!-- #post-<?php the_ID(); ?> -->