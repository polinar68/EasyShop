<?php
/**
 * The template for items list.
 */

?>
<li>
	<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
		<h3>
        <?php
            $title = get_the_title();
            print (  ( strlen( $title ) ) ? $title : "..." );
        ?>
        </h3>

	</a>
</li>	
<li>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
            <div class="featured-post">
                <?php _e( 'Featured post', 'twentytwelve' ); ?>
            </div>
		<?php endif; ?>
        <?php the_post_thumbnail(); ?>
        <p><?php _e('Posted', 'codepeople-light-text'); ?> <?php the_time(get_option('date_format'));?> <?php _e('by', 'codepeople-light-text'); ?> <?php the_author_posts_link(); ?> <?php _e('filed under', 'codepeople-light-text'); ?> <?php the_category(', '); ?> 
		<?php 
			if ( comments_open() && ! post_password_required() ) : 
				comments_popup_link( '<span class="ui-li-count">0</span>', '<span class="ui-li-count">1</span>', '<span class="ui-li-count">%</span>' ); 
				print '<strong>'.__('comments', 'codepeople-light-text').'</strong>';
			endif;	
		?>
		</p>
        <div class="entry-content">
            <p>
            <?php 
                $content = get_the_content(__("Read More", 'codepeople-light-text')); 
                $content = apply_filters('the_content', $content);
                $content = str_replace(array('<ul', '</ul>', '<ol', '</ol>'), array('<div  class="ui-li-desc"><ul', '</ul></div>', '<div class="ui-li-desc"><ol', '</ol></div>'), $content);
                print '<p>'.$content.'</p>';
            ?>
            </p>
        </div>    
		<p><?php the_tags('<span class="tags-title">'.__('Tags', 'codepeople-light-text').':</span> ', ', ', ''); ?></p>
		<?php comments_template(); ?>
    </article>    
    <div class="clear"></div>
</li>