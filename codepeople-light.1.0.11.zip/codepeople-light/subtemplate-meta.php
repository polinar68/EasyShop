<?php
/* translators: used between list items, there is a space after the comma */
$categories_list = get_the_category_list( __( ', ', 'codepeople-light-text' ) );

/* translators: used between list items, there is a space after the comma */
$tag_list = get_the_tag_list( '', __( ', ', 'codepeople-light-text' ) );

if ( '' != $tag_list ) {
    $utility_text = __( 'This entry was posted in %1$s and tagged %2$s by <a href="%6$s">%5$s</a>. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'codepeople-light-text' );
} elseif ( '' != $categories_list ) {
    $utility_text = __( 'This entry was posted in %1$s by <a href="%6$s">%5$s</a>. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'codepeople-light-text' );
} else {
    $utility_text = __( 'This entry was posted by <a href="%6$s">%5$s</a>. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'codepeople-light-text' );
}

printf(
    $utility_text,
    $categories_list,
    $tag_list,
    esc_url( get_permalink() ),
    the_title_attribute( 'echo=0' ),
    get_the_author(),
    esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) )
);
?>
<?php edit_post_link( __( 'Edit', 'codepeople-light-text' ), '<span class="edit-link">', '</span>' ); ?>

<?php if ( get_the_author_meta( 'description' ) && ( ! function_exists( 'is_multi_author' ) || is_multi_author() ) ) : // If a user has filled out their description and this is a multi-author blog, show a bio on their entries ?>
<div id="author-info" data-role="collapsible"  <?php print codepeople_light_get( 'CODEPEOPLE_LIGHT_CONTENT_THEME' ).codepeople_light_get( 'CODEPEOPLE_LIGHT_HEADER_THEME' );?> >
		<h2><?php printf( __( 'About %s', 'codepeople-light-text' ), get_the_author() ); ?></h2>
	<div>
		<div id="author-avatar">
			<?php echo get_avatar( get_the_author_meta( 'user_email' ) ); ?>
		</div><!-- #author-avatar -->
		<div id="author-description">
			
			<?php the_author_meta( 'description' ); ?>
			<div id="author-link">
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author" data-role="button" data-icon="arrow-d">
					<?php printf( __( 'View all posts by %s', 'codepeople-light-text' ), get_the_author() ); ?>
				</a>
			</div><!-- #author-link	-->
		</div><!-- #author-description -->
	</div> 
</div><!-- #entry-author-info -->
<?php endif; ?>